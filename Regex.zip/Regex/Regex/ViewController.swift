//
//  ViewController.swift
//  Regex
//
//  Created by Naveen Gundu on 04/12/16.
//  Copyright © 2016 VivekOwn. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet var textValidator: UIView!
    @IBOutlet var test: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

   @IBAction func checkregex(sender:UITextField)  {
        let regex = try! NSRegularExpression(pattern: "^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{8,}$", options: NSRegularExpression.Options())
        var checkflag = true
        if regex.firstMatch(in: sender.text!, options: NSRegularExpression.MatchingOptions(), range:NSMakeRange(0, sender.text!.characters.count)) != nil {
            
            print("could not handle special characters")
            textValidator.backgroundColor = UIColor.green
            checkflag = true
            
        }
        else
        {
            checkflag = false
            textValidator.backgroundColor = UIColor.red

            print("true")
        }
     //return checkflag
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {   //delegate method
        textField.resignFirstResponder()
        return true
    }
}

